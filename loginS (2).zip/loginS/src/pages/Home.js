// 로그인 후 회원정보를 관리하는 페이지

import React, { useState, useRef, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { Button } from "@rmwc/button"; // React Material 디자인 Button 컴포넌트 입니다.

import "@rmwc/button/styles"; // React Material Button 디자인 CSS 입니다.
import "@rmwc/data-table/styles"; // React Material Data-Table 디자인 CSS 입니다.

import "../css/home.css"; // 이 페이지의 커스텀 디자인 CSS 입니다.
const Home = () => {
  // 이부분들은 state 초기화 부분이라 보실게 없습니다.
  const history = useHistory(); // 라우팅 히스토리



  


   

  const logoutFunc = () => {
    localStorage.removeItem("login");

    if(localStorage.getItem("login_type")) {
      localStorage.removeItem("login_type");
    }

    alert("로그아웃 되었습니다.");
    history.push("/");
  }

  //아래는 JSX 껍데기및, 이벤트리스너 연동.

  return (
    <div className="wrapper table_wrapper">
      <div className="column">
        <h1 className="managementTitle">회원 관리</h1>
      </div>
      
      
        <Button
            label="로그아웃"
            outlined
            className="logoutButton"
            onClick={logoutFunc}
          />
      </div>
   
  );
};

export default Home;
